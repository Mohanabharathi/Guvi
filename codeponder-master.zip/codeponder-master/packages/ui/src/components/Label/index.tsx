import styled from "styled-components";

export const Label = styled.div`
  font-family: rubik;
  font-size: 1.2rem;
  color: #78909c;
`;
