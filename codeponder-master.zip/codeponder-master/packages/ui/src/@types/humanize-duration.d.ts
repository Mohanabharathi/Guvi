declare module "humanize-duration";
