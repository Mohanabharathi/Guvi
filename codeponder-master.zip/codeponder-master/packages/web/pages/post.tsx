import { PostView } from "../modules/post/PostView";

export default PostView;
