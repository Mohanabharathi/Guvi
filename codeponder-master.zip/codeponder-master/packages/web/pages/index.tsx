import { HomeView } from "../modules/home/HomeView";

export default HomeView;
