import { CreatePost } from "../modules/post/CreatePost";

export default CreatePost;
