export const isBrowser = typeof window !== "undefined";
