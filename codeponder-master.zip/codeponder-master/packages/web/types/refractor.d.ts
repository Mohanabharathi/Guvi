declare module "hast-to-hyperscript";
declare module "rehype";
