declare module "remark";
declare module "remark-ping";
declare module "remark-react";
declare module "rehype-stringify";
declare module "remark-parse";
declare module "remark-ping";
declare module "remark-rehype";
