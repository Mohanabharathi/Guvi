export const DISPLAY_ERROR_CODE = "display error";
